/*!
 *  \copyright This Source Code Form is subject to the terms of the Mozilla Public
 *  License, v. 2.0. If a copy of the MPL was not distributed with this
 *  file, You can obtain one at http://mozilla.org/MPL/2.0/.
 *  \author Sivaram Ambikasaran, Ruoxi Wang
 *  \version 3.1
*/
/*! \file	environment.hpp
   headers used in FLIPACK
*/
#ifndef __environment_hpp__
#define __environment_hpp__

#include"iostream"
#include <sstream>
#include<fstream>
#include <stdexcept>
#include <algorithm>
#include <cctype>
#include <string>
#include <stdlib.h>
#include<vector>
#include"cmath"
#include"Eigen/Dense"


#endif //(__environment_hpp__)
